#include <stdio.h>
#include <stdlib.h>

int main()
{
    int numero1;
    int numero2;
    int suma;

    printf("Ingrese el primero numero: ");
    scanf("\n%d",&numero1);
    printf("Ingrese el segundo numero: ");
    scanf("\n%d",&numero2);

    suma= numero1 + numero2;

    printf("La suma es: %d",suma);





    return 0;
}
