#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i;
    for(i=100;i>=0;i--)
    {
        printf("%d\n",i);
    }
}
