

int mostrar(int);
int mostrarDOS(int c);
