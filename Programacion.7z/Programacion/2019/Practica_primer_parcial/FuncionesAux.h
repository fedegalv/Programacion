void limpiarPantalla(void);
int menuOpciones(void);
int ingresoNumero(void);
int verificarCadena(char [51]);
void formateoCadenas(char* );
int verificarTarjeta(char []);
int devolverHorasEstadia();
int validacionPatente(char []);
