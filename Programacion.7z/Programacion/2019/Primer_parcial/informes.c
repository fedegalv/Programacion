#include <stdio.h>
#include <stdlib.h>
#include "string.h"
#include "ctype.h"
#include "funcionesAux.h"
#include "informes.h"
#include "pelicula.h"

void listaPeliculaSinActores(sPelicula lista[], int cantPel)
{
    int i;
    printf("\nMOSTRAR PELICULAS SIN ACTORES\n\n");
    {
        for(i=0; i < cantPel; i++)
            {
                if(lista[i].actorPrincipal.idActor == -1 && lista[i].estado ==1)
                {
                    mostrarUnaPelicula(lista[i]);
                }
            }
            limpiarPantalla();
    }

}
void listaPeliculaConActores(sPelicula lista[], int cantPel)
{
    int i;
    printf("\nMOSTRAR PELICULAS CON ACTORES\n\n");
    printf("%5s %5s %10s %10s %10s\n", "ID", "COD PEL", "TITULO")
    for(i=0; i < cantPel; i++)
    {
        if(lista[i].actorPrincipal.idActor != -1 && lista[i].estado ==1)
        {
            mostrarUnaPelicula(lista[i]);
        }
    }
    limpiarPantalla();
}
