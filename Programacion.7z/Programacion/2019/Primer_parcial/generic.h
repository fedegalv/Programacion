#ifndef generic_H
#define generic_H
typedef struct
{
    int idActor;
    char nombreActor[64];
    char paisOrigines[64];

} sActor;
typedef struct
{
    int idPelicula;
    int codigoPelicula;
    char titulo[64];
    char fechaEstreno[64];
    char genero[64];
    s
    int estado;

} sPelicula;





#endif
