#include "actores.h"
#ifndef pelicula_H
#define pelicula_H
typedef struct
{
    int idPelicula;
    char codigoPelicula[10];
    char titulo[64];
    char fechaEstreno[64];
    char genero[64];
    sActor actorPrincipal;
    int estado;

} sPelicula;

int sPelicula_Init( sPelicula listado[],int limite);
int sPelicula_buscarLugarLibre(sPelicula listado[],int limite);
int altasPelicula(sPelicula lista[], sActor listaActores[], int idAsignada, int posicionLibre);
void mostrarsPelicula(sPelicula lista[], int tam);
int verificarTitulo(char tituloPelicula[]);
int verificarCodigoPelicula(char codigoPelicula[]);
void mostrarUnaPelicula(sPelicula pelicula);


#endif
