#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pelicula.h"
#include "actores.h"
#include "funcionesAux.h"

void mostrarActores(sActor lista[], int tam)
{
    int i;
    printf("%10s %10s %20s\n","ID ACTOR","NOMBRE", "PAIS ORIGNES");
    for(i=0; i < tam; i++)
    {
        printf("%10d %25s %25s\n", lista[i].idActor, lista[i].nombreActor, lista[i].paisOrigen);
    }
    //limpiarPantalla();
}

void sActor_Hardcoded(sActor lista[])
{
    int i;
    char nombre[5][50]= {"julieta roberto", "Roberto deniro", "Richar darin", "tita merelo", "sandro"};
    int id[5] = {1, 2, 3, 4, 5};
    char paisOrigen[5][50]= {"EEUU", "EEUU", "Argentina", "Argentina", "Argentina"};

    for(i=0; i < 5; i++)
    {
        lista[i].idActor = id[i];
        strcpy(lista[i].nombreActor, nombre[i]);
        strcpy(lista[i].paisOrigen, paisOrigen[i]);
    }
}
int ingresoActor(sActor listaActores[], int tamActores)
{
    int i;
    int idActor;
    int flag=0;
    int posicionActor;
    do
    {
    printf("Eliga un actor principal: ");
    idActor= ingresoNumero();
    for(i=0; i < tamActores; i++)
    {
        if(idActor == listaActores[i].idActor)
        {
            posicionActor= i;
            //lista[idProvista].actorPrincipal = listaActores[i];
            flag=1;
            printf("Actor valido\n");
            break;
        }
    }
    }while(flag == 0);

    return posicionActor;
}
