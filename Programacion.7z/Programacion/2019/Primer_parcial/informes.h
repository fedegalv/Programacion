#include "actores.h"
#include "pelicula.h"

void listaPeliculaSinActores(sPelicula lista[], int cantPel);
void listaPeliculaConActores(sPelicula lista[], int cantPel);
