#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ctype.h"
#include "pelicula.h"
#include "pelicula.h"
#include "funcionesAux.h"
int sPelicula_Init( sPelicula listado[],int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && listado != NULL)
    {
        retorno = 0;
        for(i=0; i<limite; i++)
        {
            listado[i].estado= 0;
            listado[i].idPelicula= 0;
            listado[i].actorPrincipal.idActor = -1;
        }
    }
    return retorno;
}
int sPelicula_buscarLugarLibre(sPelicula listado[],int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && listado != NULL)
    {
        retorno = -2;
        for(i=0;i<limite;i++)
        {
            if(listado[i].estado == 0)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}
/*
void sPelicula_Hardcoded(sPelicula lista[])
{
    char textoAvisos[5][50]= {"TEXTO PRUEBA 1", "TEXTO PRUEBA 2", "TEXTO PRUEBA 3", "TEXTO PRUEBA 4", "TEXTO PRUEBA 5"};
    int id[5] = {1, 2, 3, 4, 3};
    int numeroAviso[5] = {2, 2, 3, 3, 5};

    for(int i=0; i < 5; i++)
    {
        lista[i].idCliente = id[i];
        lista[i].numeroRubro = numeroAviso[i];
        strcpy(lista[i].textoAviso, textoAvisos[i]);
        lista[i].estado= 1;
    }
}
*/

int verificarCodigoPelicula(char codigoPelicula[10])
{
    int i;
    int flag=0;
    do
    {
        if(strlen(codigoPelicula) == 3) /// SI ES DE 3 CIFRAS
        {
            if(codigoPelicula[0]  != '0')
            {
                for(i=0; i < strlen(codigoPelicula); i++)
                {
                    if( isalnum( (int)(codigoPelicula[i]) ) != 0 )
                    {
                        flag= 1;
                    }
                }
            }
        }
        if(flag == 0)
        {
            fflush(stdin);
            printf("\nCodigo Invalido, reingrese codigo de la pelicula: ");
            gets(codigoPelicula);
        }
    }while(flag ==0);
    return 0;
}
int verificarTitulo(char tituloPelicula[64])
{
    int flag=0;
    do
    {
        if(strlen(tituloPelicula) > 1 && ( isdigit( tituloPelicula[0])) == 0  ) /// SI ES DE 3 CIFRAS Y NO EMPIEZA CON NUMERO
        {
            flag =1;
        }
        else
        {
            fflush(stdin);
            printf("\nTitulo pelicula Invalido, reingrese titulo de la pelicula: ");
            gets(tituloPelicula);
        }
    }while(flag == 0);

    return 0;
}
int verificarFecha()
{
    return 0;
}


int altasPelicula(sPelicula lista[], sActor listaActores[], int idAsignada, int posicionLibre)
{
    char tituloPelicula[64];
    char fechaEstreno[64];
    char genero[64];
    char codigoPelicula[10];
    int posicionActor;

    fflush(stdin);
    printf("\nIngrese codigo de la pelicula: ");
    gets(codigoPelicula);
    verificarCodigoPelicula(codigoPelicula);
    //codigoPelicula = ingresoNumero();



    printf("\nIngrese titulo de la pelicula: ");
    gets(tituloPelicula);
    verificarTitulo(tituloPelicula);

    printf("\nIngrese fecha de estreno: ");
    gets(fechaEstreno);
    //verificarFecha(fechaEstreno);

    printf("\nIngrese genero de la pelicula: ");
    gets(genero);
    verificarCadena(genero);

    mostrarActores(listaActores, 5);
    posicionActor= ingresoActor(listaActores, 5);
////
    lista[posicionLibre].actorPrincipal.idActor= listaActores[posicionActor].idActor;
    strcpy(lista[posicionLibre].actorPrincipal.nombreActor, listaActores[posicionActor].nombreActor);
    strcpy(lista[posicionLibre].actorPrincipal.paisOrigen, listaActores[posicionActor].paisOrigen);
///
    strcpy(lista[posicionLibre].titulo, tituloPelicula);
    strcpy(lista[posicionLibre].fechaEstreno, fechaEstreno);
    strcpy(lista[posicionLibre].genero, genero);
    strcpy(lista[posicionLibre].codigoPelicula, codigoPelicula);
    lista[posicionLibre].estado= 1;
    lista[posicionLibre].idPelicula= idAsignada;//+1;
    printf("Alta exitosa\n");
    limpiarPantalla();
    return 0;
}

void mostrarsPelicula(sPelicula lista[], int tam)
{
    int i;
    printf("%10s %10s %20s\n","ID PELICULA","TITULO", "GENERO");
    for(i=0; i < tam; i++)
    {
        if(lista[i].estado == 1)
        {
            printf("%10d %10s %10s\n", lista[i].idPelicula, lista[i].titulo, lista[i].genero);

        }
    }
    limpiarPantalla();
}
void mostrarUnaPelicula(sPelicula pelicula)
{
    printf("%5d %5s %10s %10s %10s\n", pelicula.idPelicula, pelicula.codigoPelicula, pelicula.titulo, pelicula.fechaEstreno, pelicula.genero);
}
/*
int buscarsPeliculaID(sPelicula lista[], int tam)
{
    int id;
    int posicionEncontrada= -1;
    printf("Ingrese id a buscar: ");
    id= ingresoNumero();
    for(int i= 0; i < tam; i++)
    {
        if(lista[i].idCliente == id && lista[i].estado == 1)
        {
            posicionEncontrada= i;
        }
    }
    return posicionEncontrada;
}
int posicionsPeliculaID(sPelicula lista[], int tam, int idProvista)
{
    int posicionEncontrada= -1;
    for(int i= 0; i < tam; i++)
    {
        if(lista[i].idCliente == idProvista && lista[i].estado == 1)
        {
            posicionEncontrada= i;
        }
    }
    return posicionEncontrada;
}
*/
