#include <stdio.h>
#include <stdlib.h>
#include "funcionesAux.h"

int main()
{

    menuOpciones();
    return 0;
}
