int menuOpciones(void);
void limpiarPantalla(void);
int ingresoNumero(void);
int verificarCadena(char cadena[]);
void formateoCadenas(char* texto);
