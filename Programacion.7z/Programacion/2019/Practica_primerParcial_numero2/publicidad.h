
#include "publicidad.h"
#ifndef publicidad_h
#define publicidad_h
typedef struct
{
    int estado;
    int cuitCliente;
    int duracionPublicacion;
    char nombreVideo[64];
} sPublicidad;

#endif

