void ingresoNombre(char *);
void ingresoApellido(char *);
void upperPrimeraLetra(char *);
void formateoNombreApellido(char* ,char *,char *);
