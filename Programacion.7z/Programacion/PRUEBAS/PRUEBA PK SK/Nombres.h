
typedef struct
{
    int idNombre;
    char nombre[50];
    int estado;
}eNombre;

void initNameState(eNombre [], int );
void initNamesHardCoded(eNombre [], int );
void showNameList(eNombre [],int );
