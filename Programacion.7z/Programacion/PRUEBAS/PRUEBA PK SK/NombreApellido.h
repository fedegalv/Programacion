#include "Nombres.h"
#include "Apellidos.h"

typedef struct
{
    int idNombre;
    char idApellido;
}eCliente;

void inicializarSeriesUsuariosHardCode(eCliente []);
void showClientFullname (eNombre [], int tamNombre, eApellido [], int , eCliente [], int );
