
int cargarAlumnos(char[][50], int[],int[],int[],float[], int,char[], int[],int);
float calcularPromedio(int,int,int);
int inicializaNombre(char [][50]);
int mostrarResultados (char [][50], int [], char [], int [],int [],int [],float [],int);
int verificarNombre(char[50]);
int verificarNota(int);
int verificarSexo(char);
int modificarDatos(char [][50] ,int [],char [],int [],int [],int [],float [],int);
int modificaAlumnos(char[][50], int[],int[],int[],float[], int,char[], int[],int);
int alumnosPromedioMayor6(int[],float []);
