typedef struct // DEFINICION DE ESTRUCTURA SE PONE EN BIBLIOTECA
{
    int legajo;
    char nombre[30];
    float sueldo;
    char cargo[30];
} eEmployee;
