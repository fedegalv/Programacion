#include <stdio.h>
#include <stdlib.h>
#include "Employee.h"
#define E 5

int main()
{
    eEmployee nominaEmpleados[E];





    return 0;
}
