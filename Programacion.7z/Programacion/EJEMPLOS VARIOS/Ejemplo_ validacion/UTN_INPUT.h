 int pedirEntero(char [], int, int);
 int validarEntero(int,char [], int,int);
