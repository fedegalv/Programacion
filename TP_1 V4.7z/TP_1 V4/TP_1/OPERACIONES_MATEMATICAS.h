float operacionSuma(float, float);
float operacionResta(float, float);
float operacionMultiplicacion(float,float);
float operacionDivision(float,float);
void operacionFactorial(int,int,unsigned int*,unsigned int*);
