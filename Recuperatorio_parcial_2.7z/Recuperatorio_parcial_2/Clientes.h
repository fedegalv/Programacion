#include "LinkedList.h"
struct
{
    int id;
    char nombre[51];
    int sexo;
    int numeroTelefono;
    int importe;

}typedef eCliente;

struct
{
    int id;
    int tipo;
    int idCliente;
    int importeFinal;

}typedef eAbono;
