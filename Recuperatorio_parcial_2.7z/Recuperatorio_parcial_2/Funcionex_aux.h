void wipeScreen(void);
int verificarCadena(char cadena[]);
int verificarSexo(char sexo[]);
int validarTelefono(char [] );
int verificarNombre (char [] );
int verificarImporte(int importe);
